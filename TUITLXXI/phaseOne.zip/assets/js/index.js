//I GET THE IMAGE
function update(e) {
 
 //console.log(e.target)
 var output = document.getElementById("output-image");
 output.src= URL.createObjectURL(e.target.files[0])
}
